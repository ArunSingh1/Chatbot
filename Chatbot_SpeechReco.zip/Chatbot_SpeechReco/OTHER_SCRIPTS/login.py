from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL,MySQLdb
import ctypes

app = Flask(__name__)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'acumen_flask'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
mysql = MySQL(app)

@app.route('/')
def home():
    return render_template("login.html")

'''@app.route('/dashboard')
def dashboard():
    if value_name="":
        return "Please login to continue"
    else:
        return render_template("dashboard.html")
'''
@app.route('/reg', methods=["GET", "POST"])

def register():
    if request.method == 'GET':
        return render_template("register.html")
    else:
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users (name, email, password) VALUES (%s,%s,%s)",(name,email,password))
        mysql.connection.commit()
        session['name'] = request.form['name']
        session['email'] = request.form['email']
        return render_template('dashboard.html', value_name=name )
        #return redirect(url_for('dashboard'))


#@app.route('/login',methods=["GET","POST"])
@app.route('/login',methods=["GET","POST"])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        curl = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        curl.execute("SELECT * FROM users WHERE email=%s and password=%s",(email,password))
        user = curl.fetchone()
        curl.execute("SELECT name FROM users WHERE email=%s and password=%s",(email,password))
        name=curl.fetchone()
        curl.close()

    if user is None:
        return "Incorrect username & password"
    else:
        return render_template('dashboard.html', value_name=name)


def db_validate(user,account):
    curl = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    curl.execute("SELECT * FROM users WHERE user=%s and account=%s",(user,account))
    user = curl.fetchone()
    if user:
        return True
    return False

@app.route('/logout')
def logout():
    session.clear()
    return render_template("login.html")



if __name__ == '__main__':
    app.secret_key = "^A%DJAJU^JJ123"
    app.run(debug=True,port=8080)
