from flask import Flask, render_template, request, session
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
import os
import sys
from chatterbot.trainers import ListTrainer
from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL,MySQLdb
import ctypes
from email_trigger import py_mail


old_stdout = sys.stdout


from flask import Flask, render_template
from flask_socketio import SocketIO, emit

global user_details
global CHAT_MODE

user_details={}
global bot 
bot = ChatBot('MaNoJ Creations')
# bot.set_trainer(ListTrainer)
trainer= ChatterBotCorpusTrainer(bot)

corpus_path='files/'

for file in os.listdir(corpus_path):
    trainer.train(corpus_path + file)

app = Flask(__name__)
app.secret_key = 'weqrwerkjfaeqr231wdmanoZxcxcv'
app.config[ 'SECRET_KEY' ] = 'jsbcfsbfjefebw237u3gdbdc'
CHAT_MODE='root'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'bot_data'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
mysql = MySQL(app)



socketio = SocketIO( app )
user_name=None
user_id=None

def db_validate(user,account):
    curl = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    curl.execute("SELECT email FROM customer_data WHERE name=%s and account_no=%s",(user,account))
    email = curl.fetchone()
    print('Email ',email)

    if user:
        return email
    return None

def get_id(userText):
    global CHAT_MODE
    print(f'user id:{userText}')
    user_details['account_id']= userText
    email_dict=db_validate(user_details['user_name'],user_details['account_id'])
    CHAT_MODE ='root'
    if email_dict:
        try:
            return "Thank you!, I have raised a ticket for you, please check your mail for details"
        finally:
            py_mail(TO=email_dict.get('email'))
        
    else:
        return 'Invalid details'

def create_mobile_ticket(userText):
    global CHAT_MODE
    CHAT_MODE='mobile'
    user_name=userText
    user_details['user_name']= user_name
    print(f"username:{userText}")
    CHAT_MODE='get_id'
    return "Please enter account id"

@app.route('/chat')
def chat():
    # socketio.run(app)
    
    # def hello():
    print("Function called! for live chat")
    return render_template( './ChatApp.html' )
def messageRecived():
        print( 'message was received!!!' )

@socketio.on( 'my event' )
def handle_my_custom_event( json ):
    print( 'recived my event: ' + str( json ) )
    socketio.emit( 'my response', json, callback=messageRecived )

def get_bot_response(userText):
    global CHAT_MODE
    response=bot.get_response(userText)
    # return str(response)
    print(f'response is {response}')
    if "create_mobile_ticket()" in str(response):
        try:
            print(f'confidence score:{response.confidence}')
            CHAT_MODE='mobile'
            #s=create_mobile_ticket()
            return "Okay, I'll create a ticket for you now!, Please tell me your name"
        finally:
            name=request.args.get('msg')
            print("The name is",name)

    if(response.confidence>0.7):
        print(f'confidence score:{response.confidence}')
        return str(response)
    else:
        try:
            print(f'confidence score:{response.confidence}')
            response='''Sorry I cannot help you at this moment, Human will continue this chat <a target="_blank" href="http://localhost:9988/chat">Click Here to continue</a>'''
            # userText = request.args.get('msg')
            print('B')
            chat()
            print('C')
            # response='Sorry I cannot find the answer for you.. I have saved it for you, Soon this question will be updated'
            f_txt='FAQ/'+'FAQ'+ ".txt"
            f=open(f_txt,"a")
            sys.stdout=f
            print(userText)
            f.close()
            sys.stdout.close() 
            sys.stdout = old_stdout
            return str(response)
        finally:
            pass
            # chat()
            # print("Function called!")

@app.route("/")
def home():
    # user= os.urandom(14)
    # if user not in session['user']:
    #     session['user']=user
    return render_template("index.html")

config_dict={'root':get_bot_response,'get_id':get_id,'mobile':create_mobile_ticket}


@app.route("/get")

def ccc():
    # global CHAT_MODE
    # if 'user' in session and 'user'==session['user']:
    print(f'current chat mode = {CHAT_MODE}')
    userText = request.args.get('msg')
    if CHAT_MODE=='mobile':
        res=create_mobile_ticket(userText)
        print(CHAT_MODE)
    elif CHAT_MODE=='get_id':
        res=get_id(userText)
        print(CHAT_MODE)
    else:
        res=get_bot_response(userText)
        print(CHAT_MODE)
    print('user_details',user_details)
    return res
    




if __name__ == "__main__":
    #app.run(port=9988)
    socketio.run(app,port=9988,debug=True,host='0.0.0.0')
