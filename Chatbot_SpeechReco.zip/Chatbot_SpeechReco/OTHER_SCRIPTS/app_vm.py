from flask import Flask, render_template, request

from chatterbot import ChatBot

from chatterbot.trainers import ChatterBotCorpusTrainer

import os

import sys

from chatterbot.trainers import ListTrainer



old_stdout = sys.stdout





from flask import Flask, render_template

from flask_socketio import SocketIO, emit







bot = ChatBot('MaNoJ Creations')

bot.set_trainer(ListTrainer)

for _file in os.listdir('files'):

    chats=open('files/' + _file, 'r').readlines()

    bot.train(chats)    



app = Flask(__name__)



app.config[ 'SECRET_KEY' ] = 'jsbcfsbfjefebw237u3gdbdc'

socketio = SocketIO( app )



def chat():

    # socketio.run(app)

    @app.route('/chat')

    def hello():

        return render_template( './ChatApp.html' )

    def messageRecived():

        print( 'message was received!!!' )



    @socketio.on( 'my event' )

    def handle_my_custom_event( json ):

        print( 'recived my event: ' + str( json ) )

        socketio.emit( 'my response', json, callback=messageRecived )



@app.route("/")

def home():

    return render_template("index.html")



@app.route("/get")

def get_bot_response():

    userText = request.args.get('msg')

    response=bot.get_response(userText)

    # return str(response)

    if(response.confidence>0.7):

        print(response.confidence)

        return str(response)

    else:

        try:

            print(response.confidence)

            response='''Sorry I cannot help you at this moment, Human will continue this chat <a target="_blank" href="http://localhost:9988/chat">Click Here to continue</a>'''

            userText = request.args.get('msg')

            chat()

            print("Function called!")

            # response='Sorry I cannot find the answer for you.. I have saved it for you, Soon this question will be updated'

            f_txt='FAQ/'+'FAQ'+ ".txt"

            f=open(f_txt,"a")

            sys.stdout=f

            print(userText)

            f.close()

            sys.stdout.close() 

            sys.stdout = old_stdout

            return str(response)

        finally:

            pass

            # chat()

            # print("Function called!")









if __name__ == "__main__":

    #app.run(port=9988)

    socketio.run(app,port=9998,host="0.0.0.0")

