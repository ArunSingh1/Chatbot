from chatterbot.trainers import ListTrainer
from chatterbot import ChatBot
import os
import sys
import names
import gender_guesser.detector as gender
import getpass
getpass.set_echo = '#' # Setting the symbol for encryption which will going to be displayed. (Optional)
username=input("Username: ")
password=getpass.getpass("Password: ")
print('password is',password)
old_stdout = sys.stdout
option=int(input("1.Train your bot \n2.Use existing data \t"))

def bot_creation():
    bot = ChatBot('MaNoJ Creations')
    bot.set_trainer(ListTrainer)
    for _file in os.listdir('files'):
        chats=open('files/' + _file, 'r').readlines()
        bot.train(chats)    
if (option==1):
    bot_creation()    


if (option==2):
    if not os.path.exists('db.sqlite3'):
        print('we dont have a trained model, training now')
        bot_creation()
    else:
        bot = ChatBot('MaNoJ Creations')
    # if not os.path.exists('db.sqlite3'):
    #     bot.set_trainer(ListTrainer)
    #     for _file in os.listdir('files'):
    #         chats=open('files/' + _file, 'r').readlines()
    #         bot.train(chats)


print("Bot: Hi! How can I help you today")
while True:
            request = input('You: ')
            response = bot.get_response(request)
            if(response.confidence>0.7):
                print('Bot:',response)
            else:
                f_txt='FAQ/'+'FAQ'+ ".txt"
                f=open(f_txt,"a")
                sys.stdout=f
                print(request)
                f.close()
                sys.stdout.close()
                sys.stdout = old_stdout
                print('Bot: Sorry I cannot find the answer for you.. I have saved it for you, Soon this question will be updated')
            
