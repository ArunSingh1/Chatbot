from flask import Flask, render_template, request, session, redirect, url_for, g
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
import os
import sys
from chatterbot.trainers import ListTrainer
from chatterbot.comparisons import levenshtein_distance

import uuid
old_stdout = sys.stdout
from chatterbot.response_selection import get_first_response
import chatterbot
from flask_mysqldb import MySQL,MySQLdb

from flask import Flask, render_template
from chatterbot.response_selection import get_most_frequent_response
from flask_socketio import SocketIO, emit

from email_trigger import py_mail

import logging 

import requests
import datetime

logger = logging.getLogger() 
logger.setLevel(logging.CRITICAL)

global user_details
global CHAT_MODE
global user
user_details={}
global bot 
global mode
mode = 'root'
app = Flask(__name__)
app.secret_key = 'weqrwerkjfaeqr231wdmanoZxcxcv'
app.config[ 'SECRET_KEY' ] = 'jsbcfsbfjefebw237u3gdbdc'

CHAT_MODE='root'
app.config['MYSQL_HOST'] = '10.168.126.71'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'bot_data'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
mysql = MySQL(app)

def db_validate(user,account):
    curl = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    curl.execute("SELECT email FROM customer_data WHERE name=%s and password=%s",(user,account))
    # curl.execute("SELECT email FROM customer_data WHERE name=%s and account_no=%s",(user,account))
    email = curl.fetchone()
    print('Email ',email)

    if user:
        return email
    return None


bot = ChatBot('MaNoJ Creations',
                read_only=True,
                response_selection_method=get_most_frequent_response,
                statement_comparison_function=levenshtein_distance,
             )

# bot = ChatBot('Manoj',
# response_selection_method=get_most_frequent_response,
# storage_adapter='chatterbot.storage.SQLStorageAdapter',
# input_adapter='chatterbot.input.TerminalAdapter',
# output_adapter='chatterbot.output.TerminalAdapter',
# logic_adapters=[
#         {
#             'import_path': 'chatterbot.logic.BestMatch',
#             "statement_comparison_function":"chatterbot.comparisons.levenshtein_distance",
#             "response_selection_method": "chatterbot.response_selection.get_random_response",
#             'import_path': 'chatterbot.logic.BestMatch',
#             'threshold': 0.7,
#         }
#   ]

# )
           #"statement_comparison_function": "chatterbot.comparisons.JaccardSimilarity",


# bot = ChatBot(
#     'Math & Time Bot',
#     logic_adapters=[
#         'chatterbot.logic.MathematicalEvaluation',
#         'chatterbot.logic.TimeLogicAdapter',
#         'chatterbot.logic.BestMatch'
#     ]
# )


# bot.set_trainer(ListTrainer)


#list trainer comment

trainer= ChatterBotCorpusTrainer(bot)

corpus_path='files/'

for file in os.listdir(corpus_path):
    trainer.train(corpus_path + file)




socketio = SocketIO( app )
user_name=None
user_id=None

def get_id(userText,user):
    
    print(f'user id:{userText}')
    user_details['account_id']= userText
    #CHAT_MODE ='root'
    user.mode='root'
    return "Thank you!, I'll create a ticket for you if your details match in our DB"

def create_mobile_ticket(userText,user):
    global mode
    #global CHAT_MODE
    #CHAT_MODE='mobile'
    user.mode='mobile'
    user_name=userText
    user_details['user_name']= user_name
    print(f"username:{userText}")
    #CHAT_MODE='get_id'
    user.mode='get_id'

    ##create ticket ****************************************************************
    today_date= datetime.date.today()
    due_date=today_date +datetime.timedelta(4)
    due_date=due_date.strftime("%d/%m/%y")
    issue=userText
    email_id=user.user
    
    input_json={"issue":issue,"due_date":due_date,"priority":"High","email_id" :email_id}
    r=requests.post('http://10.168.126.71:8899/add_new',json=input_json)
    tic_id=r.json().get('id')
    mode='root'
    return f"your ticket has been successfully created, please use this ticket id- {tic_id} for reference"


    return 'ticket created'
    mode='get_id'
    return "Please enter account id"

@app.route('/login',methods=["GET","POST"])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        curl = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        curl.execute("SELECT email FROM customer_data WHERE email=%s and password=%s",(email,password))
        user = curl.fetchone()
        curl.execute("SELECT name FROM customer_data WHERE email=%s and password=%s",(email,password))
        name=curl.fetchone()
        curl.close()
        session['user']=email
        session['password']=password
        
    if user is None:
        return "Incorrect username & password"
    else:
        return render_template('index_two.html',value_name=name)

@app.route('/chat')
def chat():
    # socketio.run(app)
    
    # def hello():
    print("Function called! for live chat")
    return render_template( './ChatApp.html' )
def messageRecived():
        print( 'message was received!!!' )

@socketio.on( 'my event' )
def handle_my_custom_event( json ):
    print( 'recived my event: ' + str( json ) )
    socketio.emit( 'my response', json, callback=messageRecived )

def get_bot_response(userText,conversation_id):
    global session
    global mode
    response=bot.get_response(userText,conversation_id=conversation_id.user)
    # return str(response)
    print(f'response is {response}')
    if "create_mobile_ticket()" in str(response):
        try:
            print(f'confidence score:{response.confidence}')
            conversation_id.mode='mobile'
            mode='mobile'
            return 'please describe your issue', conversation_id
            #s=create_mobile_ticket()
            #email_dict=db_validate(conversation_id.user,conversation_id.password)
            #print('EMAIL DICT',email_dict)
            #if email_dict:
            today_date= datetime.date.today()
            due_date=today_date +datetime.timedelta(4)
            due_date=due_date.strftime("%d/%m/%y")
            issue=userText
            email_id=conversation_id.user
            
            input_json={"issue":issue,"due_date":due_date,"priority":"High","email_id" :email_id}
            r=requests.post('http://10.168.126.71:8899/add_new',json=input_json)
            tic_id=r.json().get('id')
            return f"your ticket has been successfully created, please use this ticket id- {tic_id} for reference",conversation_id
            #else:
             #   return 'invalid user'
        finally:
            name=request.args.get('msg')
            print("The name is",name)
            #py_mail(TO=conversation_id.user)

    if(response.confidence>0.7):
        print(f'confidence score:{response.confidence}')
        return str(response) , conversation_id
    else:
        try:
            print(f'confidence score:{response.confidence}' )
            response='''Sorry I cannot help you at this moment, Human will continue this chat <a target="_blank" href="http://localhost:9988/chat">Click Here to continue</a>'''
            # userText = request.args.get('msg')
            print('B')
            chat()
            print('C')
            # response='Sorry I cannot find the answer for you.. I have saved it for you, Soon this question will be updated'
            f_txt='FAQ/'+'FAQ'+ ".txt"
            f=open(f_txt,"a")
            sys.stdout=f
            print(userText)
            f.close()
            sys.stdout.close() 
            sys.stdout = old_stdout
            return str(response), conversation_id
        finally:
            pass
            # chat()
            # print("Function called!")

@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template("login.html")
    # if request.method == 'POST':
    #     session.pop('user', None)

    #     if request.form['password'].strip():
    #         session['user'] = request.form['username']
    #         user_name=request.form['username']
    #         acc_id=request.form['password']
    #         #email_dict=db_validate(user_name,acc_id)
    #         #if email_dict:
    #         return render_template('bot_chat.html')

    # return render_template('index.html')

config_dict={'root':get_bot_response,'get_id':get_id,'mobile':create_mobile_ticket}

@app.route('/reg', methods=["GET", "POST"])

def register():
    if request.method == 'GET':
        return render_template("register.html")
    else:
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        account_id = request.form['account_id']


        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO customer_data (name, account_no, email, password) VALUES (%s,%s,%s,%s)",(name,account_id,email,password))
        mysql.connection.commit()
        session['name'] = request.form['name']
        session['email'] = request.form['email']
        return render_template('index_two.html', value_name=name )


@app.route('/logout')
def logout():
    session.clear()
    return render_template("login.html")




def ccc():
    # print('SESSION USER: ',session['user'])
    # print('SESSION EMAIL: ',session['email'])
    print('G',g.user)
    print(g.__dict__)
    userText = request.args.get('msg')
    print('userText:',userText)
    res=get_bot_response(userText,conversation_id=g)
    print('response is: ',res)
    return str(res[0])
@app.route("/get")
def cc1c():
    global g
    global mode
    print('G',g.user)
    print(g.__dict__)
    userText = request.args.get('msg')
    if mode=='mobile':
        res=create_mobile_ticket(userText,user=g)
        
    elif mode=='get_id':
        res=get_id(userText,user=g)
        
    else:
        res=get_bot_response(userText,conversation_id=g)
        res,g=res    
    print('user_details',user_details)
    print('out:',g)
    return res

@app.before_request
def before_request():
    g.user = None
    if 'user' in session:
        g.user = session['user']
        



if __name__ == "__main__":
    #app.run(port=9988)
    socketio.run(app,port=9988,host='0.0.0.0',debug=True)
